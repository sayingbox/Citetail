---
title: "Hello, GEO World"
description: "The first post published through the CMS — proof the pipeline works end to end."
date: 2026-08-21
---

This post was written in the CMS at `/admin`, committed to GitHub as a Markdown file, and built into this page automatically by Eleventy on every Vercel deploy.

From here you can write in plain Markdown — headings, lists, images — and it'll always come out wrapped in your site's nav, footer, and CSS.
