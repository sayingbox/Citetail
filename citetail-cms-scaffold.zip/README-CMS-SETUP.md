# Setting up Sveltia CMS on your existing GitHub + Vercel site

This turns your current plain-HTML repo into: your existing pages (untouched)
+ a `/blog/` section you can publish to from `/admin` in a browser.

## Step 1 — Add these files to your repo (on your computer, or GitHub's web editor)

Drop everything in this scaffold into the ROOT of your existing repo,
next to your current `index.html`, `geo.html`, `aeo.html`, and `css/` folder:

```
your-repo/
├── index.html          ← unchanged
├── geo.html             ← unchanged
├── aeo.html              ← unchanged
├── css/style.css         ← unchanged
├── package.json          ← NEW
├── .eleventy.js           ← NEW
├── vercel.json             ← NEW
├── _includes/
│   └── post-layout.njk      ← NEW
├── posts/
│   ├── posts.json             ← NEW
│   └── hello-world.md          ← NEW (example post)
├── blog/
│   └── index.njk                ← NEW (blog listing page)
└── admin/
    ├── index.html                ← NEW (this becomes yoursite.com/admin)
    └── config.yml                  ← NEW (edit repo name + base_url, see Step 4)
```

You do NOT need to touch or move index.html, geo.html, or aeo.html —
they get copied through byte-for-byte by the Eleventy config.

## Step 2 — Test it locally (Terminal, in your repo folder)

```bash
npm install
npm run serve
```

Open `http://localhost:8080` — your existing pages should look identical,
and `http://localhost:8080/blog/` should show the example post.

## Step 3 — Set up GitHub OAuth (github.com)

This is what lets the CMS log you in with your GitHub account.

1. Go to https://github.com/settings/developers → "OAuth Apps" → "New OAuth App"
2. Application name: anything, e.g. "Citetail CMS"
3. Homepage URL: `https://yourdomain.com`
4. Authorization callback URL: leave this — you'll fill it in after Step 4
5. Click "Register application", then copy the **Client ID**
6. Click "Generate a new client secret" and copy the **Client Secret**
   (you won't be able to see it again — save it somewhere safe for now)

## Step 4 — Deploy the free auth proxy (Cloudflare dashboard)

Vercel doesn't have a built-in "Login with GitHub" like Netlify does,
so Sveltia needs a small proxy to handle that handshake. The official one
is free on Cloudflare Workers.

1. Go to https://github.com/sveltia/sveltia-cms-auth and click "Deploy to Cloudflare Workers"
   (or fork it and deploy manually if you prefer)
2. In the Cloudflare dashboard, under your Worker's Settings → Variables, add:
   - `GITHUB_CLIENT_ID` = the Client ID from Step 3
   - `GITHUB_CLIENT_SECRET` = the Client Secret from Step 3
   - `ALLOWED_DOMAINS` = `yourdomain.com`
3. Note the Worker's URL, e.g. `https://citetail-cms-auth.your-name.workers.dev`
4. Go back to your GitHub OAuth App (Step 3) and set the callback URL to:
   `https://citetail-cms-auth.your-name.workers.dev/callback`

## Step 5 — Wire it together (edit admin/config.yml in your repo)

Open `admin/config.yml` and change two lines:

```yaml
backend:
  name: github
  repo: your-github-username/your-repo-name   # <- your actual repo
  branch: main
  base_url: https://citetail-cms-auth.your-name.workers.dev   # <- your Worker URL
```

## Step 6 — Set the build command (Vercel dashboard)

Vercel should pick up `vercel.json` automatically, but to be safe:
Go to your project in the Vercel dashboard → Settings → Build & Development Settings:
- **Build Command:** `npm run build`
- **Output Directory:** `_site`
- **Install Command:** `npm install`

## Step 7 — Commit and push (Terminal or GitHub web UI)

```bash
git add .
git commit -m "Add Sveltia CMS and blog"
git push
```

Vercel auto-deploys as usual. Once it's live:

- Your site works exactly as before
- `yourdomain.com/blog/` shows the example post
- `yourdomain.com/admin` is your CMS — log in with GitHub, write a post,
  publish, and Vercel rebuilds automatically within a minute or two.

## Where each step actually happens, at a glance

| Step | Location |
|---|---|
| 1, 5, 7 | Your repo (locally or GitHub web editor) |
| 2 | Terminal on your computer |
| 3 | github.com/settings/developers |
| 4 | Cloudflare dashboard |
| 6 | Vercel dashboard |
